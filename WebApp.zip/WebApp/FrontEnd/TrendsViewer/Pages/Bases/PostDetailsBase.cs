﻿using Microsoft.AspNetCore.Components;
using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TrendsViewer.Services;

namespace TrendsViewer.Pages
{
    public class PostDetailsBase : ComponentBase
    {
        [Inject]
        public ITrendService TrendService { get; set; }

        public IEnumerable<CommentDto> Comments { get; set; }

        [Parameter]
        public string trendId { get; set; }
        [Parameter]
        public string postId { get; set; }

        public PostDto Post { get; set; } = new PostDto();

        protected async override Task OnInitializedAsync()
        {
            this.Post = new PostDto { Title = "Postarea mea", Id = Guid.NewGuid() };

            CommentDto commentDto1 = new CommentDto { Text = "comment1", Id = Guid.NewGuid(), Upvotes=10, Downvotes=20 };
            CommentDto commentDto2 = new CommentDto { Text = "comment2", Id = Guid.NewGuid(), Upvotes = 5, Downvotes = 50 };
            CommentDto commentDto3 = new CommentDto { Text = "comment3", Id = Guid.NewGuid(), Upvotes = 128, Downvotes = 4 };

            List<CommentDto> list = new List<CommentDto>();
            list.Add(commentDto1);
            list.Add(commentDto2);
            list.Add(commentDto3);

            this.Comments = list;
        }
    }
}
