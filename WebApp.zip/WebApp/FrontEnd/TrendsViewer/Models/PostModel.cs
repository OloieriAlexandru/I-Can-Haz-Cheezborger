﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TrendsViewer.Models
{
    public class PostModel
    {
    }
}
